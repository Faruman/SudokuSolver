# Sudoku Detector
Package to detect sudokus and its prefilled numbers from pictures.